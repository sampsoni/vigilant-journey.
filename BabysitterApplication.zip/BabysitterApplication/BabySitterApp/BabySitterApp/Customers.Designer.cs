﻿namespace BabySitterApp
{
    partial class Customers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Customers));
            this.clogoutBTN = new System.Windows.Forms.Button();
            this.cjobLST = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // clogoutBTN
            // 
            this.clogoutBTN.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clogoutBTN.Location = new System.Drawing.Point(27, 44);
            this.clogoutBTN.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.clogoutBTN.Name = "clogoutBTN";
            this.clogoutBTN.Size = new System.Drawing.Size(160, 54);
            this.clogoutBTN.TabIndex = 0;
            this.clogoutBTN.Text = "Log Out";
            this.clogoutBTN.UseVisualStyleBackColor = true;
            this.clogoutBTN.Click += new System.EventHandler(this.clogoutBTN_Click);
            // 
            // cjobLST
            // 
            this.cjobLST.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cjobLST.FormattingEnabled = true;
            this.cjobLST.ItemHeight = 18;
            this.cjobLST.Location = new System.Drawing.Point(27, 108);
            this.cjobLST.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.cjobLST.Name = "cjobLST";
            this.cjobLST.Size = new System.Drawing.Size(360, 220);
            this.cjobLST.TabIndex = 1;
            this.cjobLST.SelectedIndexChanged += new System.EventHandler(this.cjobLST_SelectedIndexChanged);
            // 
            // Customers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(421, 358);
            this.Controls.Add(this.cjobLST);
            this.Controls.Add(this.clogoutBTN);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.Name = "Customers";
            this.Text = "Customers Babysitter";
            this.Load += new System.EventHandler(this.Customers_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button clogoutBTN;
        public System.Windows.Forms.ListBox cjobLST;
    }
}