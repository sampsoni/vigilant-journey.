﻿namespace BabySitterApp
{
}

namespace BabySitterApp {
    
    
    public partial class BabysitterDBADataSet {
    }
}
namespace BabySitterApp {
    
    
    public partial class BabysitterDBADataSet {
    }
}
