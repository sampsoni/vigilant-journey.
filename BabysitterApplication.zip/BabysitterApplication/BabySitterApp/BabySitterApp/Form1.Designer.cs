﻿namespace BabySitterApp
{
    partial class form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form1));
            this.tabcontrol1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.clearCustBTN = new System.Windows.Forms.Button();
            this.customerdateTime = new System.Windows.Forms.DateTimePicker();
            this.label26 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.customerenterBTN = new System.Windows.Forms.Button();
            this.emailTXT = new System.Windows.Forms.TextBox();
            this.contactTXT = new System.Windows.Forms.TextBox();
            this.postcodeTXT = new System.Windows.Forms.TextBox();
            this.secondLineTXT = new System.Windows.Forms.TextBox();
            this.firstlineaddTXT = new System.Windows.Forms.TextBox();
            this.lastnameTXT = new System.Windows.Forms.TextBox();
            this.firstnameTXT = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.sstartdatePicker = new System.Windows.Forms.DateTimePicker();
            this.enddatePicker = new System.Windows.Forms.DateTimePicker();
            this.staffclearBTN = new System.Windows.Forms.Button();
            this.semailTXT = new System.Windows.Forms.TextBox();
            this.scontactTXT = new System.Windows.Forms.TextBox();
            this.spostcodeTXT = new System.Windows.Forms.TextBox();
            this.ssecondlineTXT = new System.Windows.Forms.TextBox();
            this.sfirstLineTXT = new System.Windows.Forms.TextBox();
            this.slastnameTXT = new System.Windows.Forms.TextBox();
            this.sfirstnameTXT = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.senterBTN = new System.Windows.Forms.Button();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.acceptLBL = new System.Windows.Forms.Label();
            this.allocateBTN = new System.Windows.Forms.Button();
            this.datetimeBTN = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.timeTXT = new System.Windows.Forms.TextBox();
            this.dataTXT = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.totalTXTBX = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.addressLST = new System.Windows.Forms.ListBox();
            this.fulldayBTN = new System.Windows.Forms.Button();
            this.eveningBTN = new System.Windows.Forms.Button();
            this.afternoonBTN = new System.Windows.Forms.Button();
            this.morningBTN = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.jobordernoLBL = new System.Windows.Forms.Label();
            this.printBTN = new System.Windows.Forms.Button();
            this.clearjobBTN = new System.Windows.Forms.Button();
            this.confirmBTN = new System.Windows.Forms.Button();
            this.jobLST = new System.Windows.Forms.ListBox();
            this.label31 = new System.Windows.Forms.Label();
            this.staffLST = new System.Windows.Forms.ListBox();
            this.label30 = new System.Windows.Forms.Label();
            this.customerLST = new System.Windows.Forms.ListBox();
            this.label29 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.enterBTN = new System.Windows.Forms.Button();
            this.logoutBTN = new System.Windows.Forms.Button();
            this.useridTXT = new System.Windows.Forms.TextBox();
            this.passwordTXT = new System.Windows.Forms.TextBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.infoSupportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.babysitterDBADataSet = new BabySitterApp.BabysitterDBADataSet();
            this.staffacceptBTN = new System.Windows.Forms.Button();
            this.tabcontrol1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.babysitterDBADataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // tabcontrol1
            // 
            this.tabcontrol1.Controls.Add(this.tabPage1);
            this.tabcontrol1.Controls.Add(this.tabPage7);
            this.tabcontrol1.Controls.Add(this.tabPage3);
            this.tabcontrol1.Location = new System.Drawing.Point(47, 126);
            this.tabcontrol1.Name = "tabcontrol1";
            this.tabcontrol1.SelectedIndex = 0;
            this.tabcontrol1.Size = new System.Drawing.Size(833, 399);
            this.tabcontrol1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.clearCustBTN);
            this.tabPage1.Controls.Add(this.customerdateTime);
            this.tabPage1.Controls.Add(this.label26);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.pictureBox2);
            this.tabPage1.Controls.Add(this.customerenterBTN);
            this.tabPage1.Controls.Add(this.emailTXT);
            this.tabPage1.Controls.Add(this.contactTXT);
            this.tabPage1.Controls.Add(this.postcodeTXT);
            this.tabPage1.Controls.Add(this.secondLineTXT);
            this.tabPage1.Controls.Add(this.firstlineaddTXT);
            this.tabPage1.Controls.Add(this.lastnameTXT);
            this.tabPage1.Controls.Add(this.firstnameTXT);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Location = new System.Drawing.Point(4, 27);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(825, 368);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Customer";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // clearCustBTN
            // 
            this.clearCustBTN.Location = new System.Drawing.Point(462, 311);
            this.clearCustBTN.Name = "clearCustBTN";
            this.clearCustBTN.Size = new System.Drawing.Size(100, 33);
            this.clearCustBTN.TabIndex = 23;
            this.clearCustBTN.Text = "Clear All";
            this.clearCustBTN.UseVisualStyleBackColor = true;
            this.clearCustBTN.Click += new System.EventHandler(this.clearCustBTN_Click);
            // 
            // customerdateTime
            // 
            this.customerdateTime.Location = new System.Drawing.Point(431, 245);
            this.customerdateTime.Name = "customerdateTime";
            this.customerdateTime.Size = new System.Drawing.Size(200, 26);
            this.customerdateTime.TabIndex = 22;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(428, 211);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(99, 18);
            this.label26.TabIndex = 21;
            this.label26.Text = "Start Date: ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(626, 195);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(122, 54);
            this.label13.TabIndex = 20;
            this.label13.Text = "Ability to \r\nAdd Customer\r\nPictures!!";
            this.label13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(617, 81);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(113, 18);
            this.label7.TabIndex = 19;
            this.label7.Text = "Coming Soon";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(580, 24);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(188, 158);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 18;
            this.pictureBox2.TabStop = false;
            // 
            // customerenterBTN
            // 
            this.customerenterBTN.Location = new System.Drawing.Point(630, 284);
            this.customerenterBTN.Name = "customerenterBTN";
            this.customerenterBTN.Size = new System.Drawing.Size(100, 33);
            this.customerenterBTN.TabIndex = 8;
            this.customerenterBTN.Text = "Enter";
            this.customerenterBTN.UseVisualStyleBackColor = true;
            this.customerenterBTN.Click += new System.EventHandler(this.customerenterBTN_Click);
            // 
            // emailTXT
            // 
            this.emailTXT.Location = new System.Drawing.Point(210, 291);
            this.emailTXT.Name = "emailTXT";
            this.emailTXT.Size = new System.Drawing.Size(193, 26);
            this.emailTXT.TabIndex = 17;
            // 
            // contactTXT
            // 
            this.contactTXT.Location = new System.Drawing.Point(210, 254);
            this.contactTXT.Name = "contactTXT";
            this.contactTXT.Size = new System.Drawing.Size(193, 26);
            this.contactTXT.TabIndex = 16;
            // 
            // postcodeTXT
            // 
            this.postcodeTXT.Location = new System.Drawing.Point(210, 211);
            this.postcodeTXT.Name = "postcodeTXT";
            this.postcodeTXT.Size = new System.Drawing.Size(193, 26);
            this.postcodeTXT.TabIndex = 15;
            // 
            // secondLineTXT
            // 
            this.secondLineTXT.Location = new System.Drawing.Point(210, 169);
            this.secondLineTXT.Name = "secondLineTXT";
            this.secondLineTXT.Size = new System.Drawing.Size(193, 26);
            this.secondLineTXT.TabIndex = 14;
            // 
            // firstlineaddTXT
            // 
            this.firstlineaddTXT.Location = new System.Drawing.Point(210, 132);
            this.firstlineaddTXT.Name = "firstlineaddTXT";
            this.firstlineaddTXT.Size = new System.Drawing.Size(193, 26);
            this.firstlineaddTXT.TabIndex = 13;
            // 
            // lastnameTXT
            // 
            this.lastnameTXT.Location = new System.Drawing.Point(210, 98);
            this.lastnameTXT.Name = "lastnameTXT";
            this.lastnameTXT.Size = new System.Drawing.Size(193, 26);
            this.lastnameTXT.TabIndex = 12;
            // 
            // firstnameTXT
            // 
            this.firstnameTXT.Location = new System.Drawing.Point(210, 61);
            this.firstnameTXT.Name = "firstnameTXT";
            this.firstnameTXT.Size = new System.Drawing.Size(193, 26);
            this.firstnameTXT.TabIndex = 11;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(34, 299);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(60, 18);
            this.label12.TabIndex = 10;
            this.label12.Text = "Email: ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(34, 262);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(103, 18);
            this.label11.TabIndex = 9;
            this.label11.Text = "Contact No:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(34, 219);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(89, 18);
            this.label10.TabIndex = 8;
            this.label10.Text = "Postcode:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(34, 181);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(152, 18);
            this.label9.TabIndex = 7;
            this.label9.Text = "2nd Line Address:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(34, 140);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(147, 18);
            this.label8.TabIndex = 6;
            this.label8.Text = "1st Line Address:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(34, 98);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(98, 18);
            this.label6.TabIndex = 3;
            this.label6.Text = "Last Name:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(34, 61);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 18);
            this.label5.TabIndex = 2;
            this.label5.Text = "First Name:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(167, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(123, 18);
            this.label4.TabIndex = 1;
            this.label4.Text = "display id here";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(34, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 18);
            this.label3.TabIndex = 0;
            this.label3.Text = "Customer ID:";
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.sstartdatePicker);
            this.tabPage7.Controls.Add(this.enddatePicker);
            this.tabPage7.Controls.Add(this.staffclearBTN);
            this.tabPage7.Controls.Add(this.semailTXT);
            this.tabPage7.Controls.Add(this.scontactTXT);
            this.tabPage7.Controls.Add(this.spostcodeTXT);
            this.tabPage7.Controls.Add(this.ssecondlineTXT);
            this.tabPage7.Controls.Add(this.sfirstLineTXT);
            this.tabPage7.Controls.Add(this.slastnameTXT);
            this.tabPage7.Controls.Add(this.sfirstnameTXT);
            this.tabPage7.Controls.Add(this.label43);
            this.tabPage7.Controls.Add(this.label44);
            this.tabPage7.Controls.Add(this.label46);
            this.tabPage7.Controls.Add(this.label47);
            this.tabPage7.Controls.Add(this.pictureBox4);
            this.tabPage7.Controls.Add(this.senterBTN);
            this.tabPage7.Controls.Add(this.label34);
            this.tabPage7.Controls.Add(this.label35);
            this.tabPage7.Controls.Add(this.label36);
            this.tabPage7.Controls.Add(this.label37);
            this.tabPage7.Controls.Add(this.label38);
            this.tabPage7.Controls.Add(this.label39);
            this.tabPage7.Controls.Add(this.label40);
            this.tabPage7.Controls.Add(this.label41);
            this.tabPage7.Controls.Add(this.label42);
            this.tabPage7.Location = new System.Drawing.Point(4, 27);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(825, 368);
            this.tabPage7.TabIndex = 3;
            this.tabPage7.Text = "Staff";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // sstartdatePicker
            // 
            this.sstartdatePicker.Location = new System.Drawing.Point(412, 193);
            this.sstartdatePicker.Name = "sstartdatePicker";
            this.sstartdatePicker.Size = new System.Drawing.Size(200, 26);
            this.sstartdatePicker.TabIndex = 46;
            // 
            // enddatePicker
            // 
            this.enddatePicker.Location = new System.Drawing.Point(412, 258);
            this.enddatePicker.Name = "enddatePicker";
            this.enddatePicker.Size = new System.Drawing.Size(200, 26);
            this.enddatePicker.TabIndex = 45;
            // 
            // staffclearBTN
            // 
            this.staffclearBTN.Location = new System.Drawing.Point(450, 306);
            this.staffclearBTN.Name = "staffclearBTN";
            this.staffclearBTN.Size = new System.Drawing.Size(100, 33);
            this.staffclearBTN.TabIndex = 44;
            this.staffclearBTN.Text = "Clear All";
            this.staffclearBTN.UseVisualStyleBackColor = true;
            this.staffclearBTN.Click += new System.EventHandler(this.staffclearBTN_Click);
            // 
            // semailTXT
            // 
            this.semailTXT.Location = new System.Drawing.Point(180, 302);
            this.semailTXT.Name = "semailTXT";
            this.semailTXT.Size = new System.Drawing.Size(193, 26);
            this.semailTXT.TabIndex = 34;
            // 
            // scontactTXT
            // 
            this.scontactTXT.Location = new System.Drawing.Point(180, 261);
            this.scontactTXT.Name = "scontactTXT";
            this.scontactTXT.Size = new System.Drawing.Size(193, 26);
            this.scontactTXT.TabIndex = 33;
            // 
            // spostcodeTXT
            // 
            this.spostcodeTXT.Location = new System.Drawing.Point(180, 218);
            this.spostcodeTXT.Name = "spostcodeTXT";
            this.spostcodeTXT.Size = new System.Drawing.Size(193, 26);
            this.spostcodeTXT.TabIndex = 32;
            // 
            // ssecondlineTXT
            // 
            this.ssecondlineTXT.Location = new System.Drawing.Point(180, 180);
            this.ssecondlineTXT.Name = "ssecondlineTXT";
            this.ssecondlineTXT.Size = new System.Drawing.Size(193, 26);
            this.ssecondlineTXT.TabIndex = 31;
            // 
            // sfirstLineTXT
            // 
            this.sfirstLineTXT.Location = new System.Drawing.Point(180, 138);
            this.sfirstLineTXT.Name = "sfirstLineTXT";
            this.sfirstLineTXT.Size = new System.Drawing.Size(193, 26);
            this.sfirstLineTXT.TabIndex = 30;
            // 
            // slastnameTXT
            // 
            this.slastnameTXT.Location = new System.Drawing.Point(180, 97);
            this.slastnameTXT.Name = "slastnameTXT";
            this.slastnameTXT.Size = new System.Drawing.Size(193, 26);
            this.slastnameTXT.TabIndex = 29;
            // 
            // sfirstnameTXT
            // 
            this.sfirstnameTXT.Location = new System.Drawing.Point(180, 60);
            this.sfirstnameTXT.Name = "sfirstnameTXT";
            this.sfirstnameTXT.Size = new System.Drawing.Size(193, 26);
            this.sfirstnameTXT.TabIndex = 28;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(409, 226);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(90, 18);
            this.label43.TabIndex = 41;
            this.label43.Text = "End Date: ";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(413, 170);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(99, 18);
            this.label44.TabIndex = 40;
            this.label44.Text = "Start Date: ";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(633, 209);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(122, 54);
            this.label46.TabIndex = 37;
            this.label46.Text = "Ability to \r\nAdd Customer\r\nPictures!!";
            this.label46.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(633, 83);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(113, 18);
            this.label47.TabIndex = 36;
            this.label47.Text = "Coming Soon";
            // 
            // pictureBox4
            // 
            this.pictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(605, 20);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(188, 158);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 35;
            this.pictureBox4.TabStop = false;
            // 
            // senterBTN
            // 
            this.senterBTN.Location = new System.Drawing.Point(646, 298);
            this.senterBTN.Name = "senterBTN";
            this.senterBTN.Size = new System.Drawing.Size(100, 33);
            this.senterBTN.TabIndex = 27;
            this.senterBTN.Text = "Enter";
            this.senterBTN.UseVisualStyleBackColor = true;
            this.senterBTN.Click += new System.EventHandler(this.senterBTN_Click);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(27, 306);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(60, 18);
            this.label34.TabIndex = 19;
            this.label34.Text = "Email: ";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(27, 269);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(103, 18);
            this.label35.TabIndex = 18;
            this.label35.Text = "Contact No:";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(27, 226);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(89, 18);
            this.label36.TabIndex = 17;
            this.label36.Text = "Postcode:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(27, 188);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(152, 18);
            this.label37.TabIndex = 16;
            this.label37.Text = "2nd Line Address:";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(27, 147);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(147, 18);
            this.label38.TabIndex = 15;
            this.label38.Text = "1st Line Address:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(27, 105);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(98, 18);
            this.label39.TabIndex = 14;
            this.label39.Text = "Last Name:";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(27, 68);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(99, 18);
            this.label40.TabIndex = 13;
            this.label40.Text = "First Name:";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(160, 31);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(123, 18);
            this.label41.TabIndex = 12;
            this.label41.Text = "display id here";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(27, 31);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(71, 18);
            this.label42.TabIndex = 11;
            this.label42.Text = "Staff ID:";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.staffacceptBTN);
            this.tabPage3.Controls.Add(this.acceptLBL);
            this.tabPage3.Controls.Add(this.allocateBTN);
            this.tabPage3.Controls.Add(this.datetimeBTN);
            this.tabPage3.Controls.Add(this.label17);
            this.tabPage3.Controls.Add(this.timeTXT);
            this.tabPage3.Controls.Add(this.dataTXT);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.totalTXTBX);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Controls.Add(this.addressLST);
            this.tabPage3.Controls.Add(this.fulldayBTN);
            this.tabPage3.Controls.Add(this.eveningBTN);
            this.tabPage3.Controls.Add(this.afternoonBTN);
            this.tabPage3.Controls.Add(this.morningBTN);
            this.tabPage3.Controls.Add(this.label14);
            this.tabPage3.Controls.Add(this.label33);
            this.tabPage3.Controls.Add(this.jobordernoLBL);
            this.tabPage3.Controls.Add(this.printBTN);
            this.tabPage3.Controls.Add(this.clearjobBTN);
            this.tabPage3.Controls.Add(this.confirmBTN);
            this.tabPage3.Controls.Add(this.jobLST);
            this.tabPage3.Controls.Add(this.label31);
            this.tabPage3.Controls.Add(this.staffLST);
            this.tabPage3.Controls.Add(this.label30);
            this.tabPage3.Controls.Add(this.customerLST);
            this.tabPage3.Controls.Add(this.label29);
            this.tabPage3.Location = new System.Drawing.Point(4, 27);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(825, 368);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Job";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // acceptLBL
            // 
            this.acceptLBL.AutoSize = true;
            this.acceptLBL.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acceptLBL.Location = new System.Drawing.Point(587, 213);
            this.acceptLBL.Name = "acceptLBL";
            this.acceptLBL.Size = new System.Drawing.Size(158, 24);
            this.acceptLBL.TabIndex = 27;
            this.acceptLBL.Text = "accept/decline";
            // 
            // allocateBTN
            // 
            this.allocateBTN.Location = new System.Drawing.Point(473, 258);
            this.allocateBTN.Name = "allocateBTN";
            this.allocateBTN.Size = new System.Drawing.Size(100, 33);
            this.allocateBTN.TabIndex = 26;
            this.allocateBTN.Text = "Send Job";
            this.allocateBTN.UseVisualStyleBackColor = true;
            this.allocateBTN.Click += new System.EventHandler(this.allocateBTN_Click);
            // 
            // datetimeBTN
            // 
            this.datetimeBTN.Location = new System.Drawing.Point(328, 244);
            this.datetimeBTN.Name = "datetimeBTN";
            this.datetimeBTN.Size = new System.Drawing.Size(75, 61);
            this.datetimeBTN.TabIndex = 25;
            this.datetimeBTN.Text = "Enter";
            this.datetimeBTN.UseVisualStyleBackColor = true;
            this.datetimeBTN.Click += new System.EventHandler(this.datetimeBTN_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(28, 287);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(51, 18);
            this.label17.TabIndex = 24;
            this.label17.Text = "Time:";
            // 
            // timeTXT
            // 
            this.timeTXT.Location = new System.Drawing.Point(133, 284);
            this.timeTXT.Name = "timeTXT";
            this.timeTXT.Size = new System.Drawing.Size(189, 26);
            this.timeTXT.TabIndex = 23;
            // 
            // dataTXT
            // 
            this.dataTXT.Location = new System.Drawing.Point(133, 244);
            this.dataTXT.Name = "dataTXT";
            this.dataTXT.Size = new System.Drawing.Size(189, 26);
            this.dataTXT.TabIndex = 22;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(360, 202);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 18);
            this.label16.TabIndex = 21;
            this.label16.Text = "Total:";
            // 
            // totalTXTBX
            // 
            this.totalTXTBX.Location = new System.Drawing.Point(417, 199);
            this.totalTXTBX.Name = "totalTXTBX";
            this.totalTXTBX.Size = new System.Drawing.Size(100, 26);
            this.totalTXTBX.TabIndex = 20;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(28, 103);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(80, 18);
            this.label15.TabIndex = 19;
            this.label15.Text = "Address:";
            // 
            // addressLST
            // 
            this.addressLST.FormattingEnabled = true;
            this.addressLST.ItemHeight = 18;
            this.addressLST.Location = new System.Drawing.Point(133, 103);
            this.addressLST.Name = "addressLST";
            this.addressLST.Size = new System.Drawing.Size(189, 58);
            this.addressLST.TabIndex = 18;
            this.addressLST.SelectedIndexChanged += new System.EventHandler(this.addressLST_SelectedIndexChanged);
            // 
            // fulldayBTN
            // 
            this.fulldayBTN.Location = new System.Drawing.Point(467, 316);
            this.fulldayBTN.Name = "fulldayBTN";
            this.fulldayBTN.Size = new System.Drawing.Size(106, 39);
            this.fulldayBTN.TabIndex = 17;
            this.fulldayBTN.Text = "Full Day";
            this.fulldayBTN.UseVisualStyleBackColor = true;
            this.fulldayBTN.Click += new System.EventHandler(this.fulldayBTN_Click);
            // 
            // eveningBTN
            // 
            this.eveningBTN.Location = new System.Drawing.Point(355, 316);
            this.eveningBTN.Name = "eveningBTN";
            this.eveningBTN.Size = new System.Drawing.Size(106, 39);
            this.eveningBTN.TabIndex = 16;
            this.eveningBTN.Text = "Evening";
            this.eveningBTN.UseVisualStyleBackColor = true;
            this.eveningBTN.Click += new System.EventHandler(this.eveningBTN_Click);
            // 
            // afternoonBTN
            // 
            this.afternoonBTN.Location = new System.Drawing.Point(243, 316);
            this.afternoonBTN.Name = "afternoonBTN";
            this.afternoonBTN.Size = new System.Drawing.Size(106, 39);
            this.afternoonBTN.TabIndex = 15;
            this.afternoonBTN.Text = "Afternoon";
            this.afternoonBTN.UseVisualStyleBackColor = true;
            this.afternoonBTN.Click += new System.EventHandler(this.afternoonBTN_Click);
            // 
            // morningBTN
            // 
            this.morningBTN.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.morningBTN.Location = new System.Drawing.Point(133, 316);
            this.morningBTN.Name = "morningBTN";
            this.morningBTN.Size = new System.Drawing.Size(104, 39);
            this.morningBTN.TabIndex = 14;
            this.morningBTN.Text = "Morning";
            this.morningBTN.UseVisualStyleBackColor = true;
            this.morningBTN.Click += new System.EventHandler(this.morningBTN_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(28, 322);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(83, 18);
            this.label14.TabIndex = 13;
            this.label14.Text = "Payment:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(734, 12);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(61, 18);
            this.label33.TabIndex = 12;
            this.label33.Text = "Job Id:";
            // 
            // jobordernoLBL
            // 
            this.jobordernoLBL.AutoSize = true;
            this.jobordernoLBL.Location = new System.Drawing.Point(718, 36);
            this.jobordernoLBL.Name = "jobordernoLBL";
            this.jobordernoLBL.Size = new System.Drawing.Size(86, 18);
            this.jobordernoLBL.TabIndex = 11;
            this.jobordernoLBL.Text = "display id ";
            // 
            // printBTN
            // 
            this.printBTN.Location = new System.Drawing.Point(718, 76);
            this.printBTN.Name = "printBTN";
            this.printBTN.Size = new System.Drawing.Size(100, 33);
            this.printBTN.TabIndex = 10;
            this.printBTN.Text = "Reciept";
            this.printBTN.UseVisualStyleBackColor = true;
            // 
            // clearjobBTN
            // 
            this.clearjobBTN.Location = new System.Drawing.Point(718, 128);
            this.clearjobBTN.Name = "clearjobBTN";
            this.clearjobBTN.Size = new System.Drawing.Size(100, 33);
            this.clearjobBTN.TabIndex = 9;
            this.clearjobBTN.Text = "Clear All";
            this.clearjobBTN.UseVisualStyleBackColor = true;
            this.clearjobBTN.Click += new System.EventHandler(this.clearjobBTN_Click);
            // 
            // confirmBTN
            // 
            this.confirmBTN.Location = new System.Drawing.Point(704, 258);
            this.confirmBTN.Name = "confirmBTN";
            this.confirmBTN.Size = new System.Drawing.Size(100, 33);
            this.confirmBTN.TabIndex = 8;
            this.confirmBTN.Text = "Confirm";
            this.confirmBTN.UseVisualStyleBackColor = true;
            this.confirmBTN.Click += new System.EventHandler(this.confirmBTN_Click);
            // 
            // jobLST
            // 
            this.jobLST.FormattingEnabled = true;
            this.jobLST.ItemHeight = 18;
            this.jobLST.Location = new System.Drawing.Point(355, 27);
            this.jobLST.Name = "jobLST";
            this.jobLST.Size = new System.Drawing.Size(357, 166);
            this.jobLST.TabIndex = 6;
            this.jobLST.SelectedIndexChanged += new System.EventHandler(this.jobLST_SelectedIndexChanged);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(28, 244);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(51, 18);
            this.label31.TabIndex = 4;
            this.label31.Text = "Date:";
            // 
            // staffLST
            // 
            this.staffLST.FormattingEnabled = true;
            this.staffLST.ItemHeight = 18;
            this.staffLST.Location = new System.Drawing.Point(133, 167);
            this.staffLST.Name = "staffLST";
            this.staffLST.Size = new System.Drawing.Size(189, 58);
            this.staffLST.TabIndex = 3;
            this.staffLST.SelectedIndexChanged += new System.EventHandler(this.staffLST_SelectedIndexChanged);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(28, 185);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(50, 18);
            this.label30.TabIndex = 2;
            this.label30.Text = "Staff:";
            // 
            // customerLST
            // 
            this.customerLST.FormattingEnabled = true;
            this.customerLST.ItemHeight = 18;
            this.customerLST.Location = new System.Drawing.Point(133, 36);
            this.customerLST.Name = "customerLST";
            this.customerLST.Size = new System.Drawing.Size(189, 58);
            this.customerLST.TabIndex = 1;
            this.customerLST.SelectedIndexChanged += new System.EventHandler(this.customerLST_SelectedIndexChanged);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(24, 36);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(91, 18);
            this.label29.TabIndex = 0;
            this.label29.Text = "Customer:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(468, 28);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(429, 113);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(55, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 18);
            this.label1.TabIndex = 2;
            this.label1.Text = "User ID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(55, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 18);
            this.label2.TabIndex = 3;
            this.label2.Text = "Password:";
            // 
            // enterBTN
            // 
            this.enterBTN.Location = new System.Drawing.Point(344, 42);
            this.enterBTN.Name = "enterBTN";
            this.enterBTN.Size = new System.Drawing.Size(100, 33);
            this.enterBTN.TabIndex = 4;
            this.enterBTN.Text = "Enter";
            this.enterBTN.UseVisualStyleBackColor = true;
            this.enterBTN.Click += new System.EventHandler(this.enterBTN_Click);
            // 
            // logoutBTN
            // 
            this.logoutBTN.Location = new System.Drawing.Point(344, 88);
            this.logoutBTN.Name = "logoutBTN";
            this.logoutBTN.Size = new System.Drawing.Size(100, 33);
            this.logoutBTN.TabIndex = 5;
            this.logoutBTN.Text = "Log Out";
            this.logoutBTN.UseVisualStyleBackColor = true;
            this.logoutBTN.Click += new System.EventHandler(this.logoutBTN_Click);
            // 
            // useridTXT
            // 
            this.useridTXT.Location = new System.Drawing.Point(168, 42);
            this.useridTXT.Name = "useridTXT";
            this.useridTXT.Size = new System.Drawing.Size(151, 26);
            this.useridTXT.TabIndex = 6;
            // 
            // passwordTXT
            // 
            this.passwordTXT.Location = new System.Drawing.Point(168, 79);
            this.passwordTXT.Name = "passwordTXT";
            this.passwordTXT.Size = new System.Drawing.Size(151, 26);
            this.passwordTXT.TabIndex = 7;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButton1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(939, 25);
            this.toolStrip1.TabIndex = 8;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.exitToolStripMenuItem,
            this.infoSupportToolStripMenuItem});
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(29, 22);
            this.toolStripDropDownButton1.Text = "toolStripDropDownButton1";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.newToolStripMenuItem.Text = "New";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.saveToolStripMenuItem.Text = "Save";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // infoSupportToolStripMenuItem
            // 
            this.infoSupportToolStripMenuItem.Name = "infoSupportToolStripMenuItem";
            this.infoSupportToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.infoSupportToolStripMenuItem.Text = "Info/Support";
            this.infoSupportToolStripMenuItem.Click += new System.EventHandler(this.infoSupportToolStripMenuItem_Click);
            // 
            // printDialog1
            // 
            this.printDialog1.UseEXDialog = true;
            // 
            // babysitterDBADataSet
            // 
            this.babysitterDBADataSet.DataSetName = "BabysitterDBADataSet";
            this.babysitterDBADataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // staffacceptBTN
            // 
         
            // 
            // form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(939, 537);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.passwordTXT);
            this.Controls.Add(this.useridTXT);
            this.Controls.Add(this.logoutBTN);
            this.Controls.Add(this.enterBTN);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.tabcontrol1);
            this.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BabySitter - Managers";
            this.Load += new System.EventHandler(this.form1_Load);
            this.tabcontrol1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.babysitterDBADataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabcontrol1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button enterBTN;
        private System.Windows.Forms.Button logoutBTN;
        private System.Windows.Forms.TextBox useridTXT;
        private System.Windows.Forms.TextBox passwordTXT;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox firstlineaddTXT;
        private System.Windows.Forms.TextBox lastnameTXT;
        private System.Windows.Forms.TextBox firstnameTXT;
        private System.Windows.Forms.TextBox emailTXT;
        private System.Windows.Forms.TextBox contactTXT;
        private System.Windows.Forms.TextBox postcodeTXT;
        private System.Windows.Forms.TextBox secondLineTXT;
        private System.Windows.Forms.Button customerenterBTN;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ListBox staffLST;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.ListBox customerLST;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label jobordernoLBL;
        private System.Windows.Forms.Button printBTN;
        private System.Windows.Forms.Button clearjobBTN;
        private System.Windows.Forms.Button confirmBTN;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox semailTXT;
        private System.Windows.Forms.TextBox scontactTXT;
        private System.Windows.Forms.TextBox spostcodeTXT;
        private System.Windows.Forms.TextBox ssecondlineTXT;
        private System.Windows.Forms.TextBox sfirstLineTXT;
        private System.Windows.Forms.TextBox slastnameTXT;
        private System.Windows.Forms.TextBox sfirstnameTXT;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button senterBTN;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem infoSupportToolStripMenuItem;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Windows.Forms.Button fulldayBTN;
        private System.Windows.Forms.Button eveningBTN;
        private System.Windows.Forms.Button afternoonBTN;
        private System.Windows.Forms.Button morningBTN;
        private BabysitterDBADataSet babysitterDBADataSet;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ListBox addressLST;
        private System.Windows.Forms.DateTimePicker customerdateTime;
        private System.Windows.Forms.Button clearCustBTN;
        private System.Windows.Forms.DateTimePicker sstartdatePicker;
        private System.Windows.Forms.DateTimePicker enddatePicker;
        private System.Windows.Forms.Button staffclearBTN;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox totalTXTBX;
        private System.Windows.Forms.Button datetimeBTN;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox timeTXT;
        private System.Windows.Forms.TextBox dataTXT;
        public System.Windows.Forms.ListBox jobLST;
        private System.Windows.Forms.Button allocateBTN;
        public System.Windows.Forms.Label acceptLBL;
        private System.Windows.Forms.Button staffacceptBTN;
    }
}

