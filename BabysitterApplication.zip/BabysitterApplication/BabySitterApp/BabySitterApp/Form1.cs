﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.IO; //This is required to read and write to the file in order to print receipt

namespace BabySitterApp
{
    public partial class form1 : Form
    {
        #region Connection Variable and Connection Data
        //The connection tells the rest of the ADO.NET code which database it is talking to
        SqlConnection connection;

        //variable to the class to be used to show where the database is and how to connect to it 
        string connectionString;

        #endregion

        #region Application Variables

        //Job Order ID Variable
        public int jobordernumber;
        //Job Payment Variable
        public double jobpaymenttotal = 0;

        //Declare variable and set to application path
        public string appPath = AppDomain.CurrentDomain.BaseDirectory;
        //Create an empty varaible to store job list file name
        public string jobfilename;

        private StreamReader myReader;

        #endregion

        #region Job packages Variables and set prices

        //Babysitter job available to book on system, declare the variables and set prices
        public double morning = 21.00;
        public double afternoon = 22.00;
        public double evening = 23.00;
        public double fullday = 60.00;
        private ListBox.ObjectCollection items;

        #endregion

        #region Custom Methods = Clear Job List, New Job Order, Save Order
        //clear job list
        private void Clearlist()
        {
            jobpaymenttotal = 0;
            totalTXTBX.Text = "";
            jobLST.Items.Clear();
            //
        }
        //New Job order number
        private void NewJobRef()
        {
            jobordernumber++; //Increase by 1 job number
            jobordernoLBL.Text = jobordernumber.ToString();  //Displays new order number
            jobLST.Items.Clear();  // Clears the job list box

        }

        private void Printreceipt()
        {// this d=code allows the job to be printed off to use it as a receipt for the customers booked job
            jobLST.Items.Add("This is the job customer and staff details including Date and Time:");
            jobLST.Items.Add(customerLST.Text);
            jobLST.Items.Add(staffLST.Text);


            jobfilename = appPath + "\\" + jobordernumber.ToString() + "Job "; //set the file path for jobfle to open.

            System.IO.StreamWriter JobobjWriter;

            JobobjWriter = new System.IO.StreamWriter(jobfilename);
            foreach (var item in jobLST.Items)
            {
                JobobjWriter.WriteLine(item + "\n");
            }

            JobobjWriter.Close();

        }
        #endregion
        public form1()
        {
            InitializeComponent();
            //ConfigurationManager class enables you to access machine, application, and user configuration information
            //sets the string used to open an SQL Server database

            connectionString = ConfigurationManager.ConnectionStrings["BabySitterApp.Properties.Settings.BabysitterDBAConnectionString"].ConnectionString;

        }


        #region This code links the text box on the staff interface to the label on the manager interface
        public form1(string text)
        {
            InitializeComponent();
            acceptLBL.Text = text;
        }

        #endregion
        #region Form Load Data

        private void form1_Load(object sender, EventArgs e)
        {

            //the below code prevents this tab from being selected until the user id has been inputted correctly
            tabcontrol1.Enabled = false;

            // the below code prevents the help strip tool bar from being used until the user has logged into system.
            toolStripDropDownButton1.Enabled = false;


            //read the last order number from the user settings
            // jobordernumber = Properties.Settings.Default.jordernumber;
            //increase order number by one
            jobordernumber++;

            //Dislay the order number in the label on the job screen after converting to string
            jobordernoLBL.Text = jobordernumber.ToString();

            //Populate Customer and Staff details.
            PopulateCustomers();
            PopulateEmployees();




            #endregion


        }



        #region Babysitter Methods & SQL Database Autofil Staff, Customer and Adress details on job page

        private void PopulateCustomers()
        {

            //Represents a set of data commands and a database connection that are used to fill the DataSet and update a SQL Server database

            using (connection = new SqlConnection(connectionString))
            using (SqlDataAdapter adapter = new SqlDataAdapter(" SELECT * FROM CUSTOMER", connection))
            {
                DataTable customerTable = new DataTable();
                adapter.Fill(customerTable);

                customerLST.DisplayMember = "firstname";
                customerLST.ValueMember = "Id";
                customerLST.DataSource = customerTable;
            }
        }

        private void PopulateEmployees()
        {
            using (connection = new SqlConnection(connectionString))
            using (SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM EMPLOYEES", connection))
            {

                DataTable employeesTable = new DataTable();
                adapter.Fill(employeesTable);

                staffLST.DisplayMember = "firstname";
                staffLST.ValueMember = "Id";
                staffLST.DataSource = employeesTable;
            }
        }

        private void PopulateAddresses()
        {
            using (connection = new SqlConnection(connectionString))
            using (SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM ADDRESSES", connection))
            {

                DataTable addressesTable = new DataTable();
                adapter.Fill(addressesTable);

                addressLST.DisplayMember = "addressline1";
                addressLST.ValueMember = "Id";
                addressLST.DataSource = addressesTable;
            }
        }

        private void AddCustomerAddress()
        {
            {
                string addressline1 = firstlineaddTXT.Text;
                string addressline2 = secondLineTXT.Text;
                string postcode = postcodeTXT.Text;
                string query = "INSERT INTO Addresses (addressline1, addressline2, postcode) " +
                "VALUES('" + addressline1 + "', '" + addressline2 + "', '" + postcode + "')";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                    }
                }
            }
        }

        private void AddStaffAddress()
        {
            {
                //The below code inputs the staff address details into the database 
                string addressline1 = sfirstLineTXT.Text;
                string addressline2 = ssecondlineTXT.Text;
                string postcode = spostcodeTXT.Text;
                string query = "INSERT INTO Addresses (addressline1, addressline2, postcode) " +
                "VALUES('" + addressline1 + "', '" + addressline2 + "', '" + postcode + "')";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                    }
                }
            }
        }

        #endregion




        #region Login Button
        public void enterBTN_Click(object sender, EventArgs e)
        {
            // Manager login and password details inputted if incorrect details inputted access will not be granted
            if (useridTXT.Text == "Elisa" & passwordTXT.Text == "abc123")
            {
                MessageBox.Show("Hi Manager, Hope your having a great day lets get to work");
                tabcontrol1.Enabled = true; //This will then unlock the tabcontrol1 allowing the user to begin to add customer, staff and job

                //once user has logged in correctly the help strip tool bar will be unlocked for use
                toolStripDropDownButton1.Enabled = true;

                // This code will clear the password text box for secuirty reasons 
                passwordTXT.Clear();
                PopulateAddresses();
                PopulateCustomers();
                PopulateEmployees();
                Clearlist();

            }

            else if (useridTXT.Text == "Customer" & passwordTXT.Text == "123abc")
            {
                Customers frm = new Customers();
                frm.Show();

            }
            else if (useridTXT.Text == "Staff" & passwordTXT.Text == "123456")
            {
                Staff frm = new Staff();
                frm.Show();

            }


            else
            {  // If incorrect username and password inputted the below message will appear

                MessageBox.Show("Login details are incorrect please try again");
                useridTXT.Clear();
                passwordTXT.Clear();

            }
            #endregion


        }

        #region Log Out Button
        private void logoutBTN_Click(object sender, EventArgs e)
        {
            //This code allows user to log out of application
            this.Close();
        }
        #endregion

        #region Add Customer to Job List Box / Coding
        private void customerLST_SelectedIndexChanged(object sender, EventArgs e)
        {
            //The below code adds the customer name to the job list box


            foreach (var item in customerLST.SelectedItems)
            {

                jobLST.Items.Add("CUSTOMER NAME:  " + customerLST.Text);
            }


        }


        #endregion


        #region Customer Enter Button Code
        private void customerenterBTN_Click(object sender, EventArgs e)
        {
            string firstname = firstnameTXT.Text;
            string lastname = lastnameTXT.Text;
            string contactno = contactTXT.Text;
            string email = emailTXT.Text;
            string startdate = customerdateTime.Text;

            string query = "INSERT INTO Customer (firstname, lastname, contactno, email, startdate) " +
                 "VALUES('" + firstname + "', '" + lastname + "', '" + contactno + "', '" + email + "', '" + startdate + "')";


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }

            PopulateCustomers();
            AddCustomerAddress();

        }
        #endregion


        #region Customer Clear All Button
        private void clearCustBTN_Click(object sender, EventArgs e)
        {
            //the below coding deletes all the data inputted into text boxes on the customer tab
            useridTXT.Clear();
            firstnameTXT.Clear();
            lastnameTXT.Clear();
            contactTXT.Clear();
            emailTXT.Clear();
            firstlineaddTXT.Clear();
            secondLineTXT.Clear();
            postcodeTXT.Clear();

        }

        #endregion


        #region Staff Enter Details button code
        private void senterBTN_Click(object sender, EventArgs e)
        {

            //The below code allows the user to input the staff details into the database
            string firstname = sfirstnameTXT.Text;
            string lastname = slastnameTXT.Text;
            string contact = scontactTXT.Text;
            string email = semailTXT.Text;
            string startdate = sstartdatePicker.Text;
            string enddate = enddatePicker.Text;

            string query = "INSERT INTO Employees (firstname, lastname, contactno, email, startdate, enddate) " +
                 "VALUES('" + firstname + "', '" + lastname + "', '" + contact + "', '" + email + "', '" + startdate + "', '" + enddate + "')";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }


            PopulateAddresses();
            PopulateCustomers();
            PopulateEmployees();
            AddStaffAddress();
        }
        #endregion


        #region Staff Clear All Button
        private void staffclearBTN_Click(object sender, EventArgs e)
        {
            //the below coding deletes all the data inputted into text boxes on the customer tab

            sfirstnameTXT.Clear();
            slastnameTXT.Clear();
            scontactTXT.Clear();
            semailTXT.Clear();
            sfirstLineTXT.Clear();
            ssecondlineTXT.Clear();
            spostcodeTXT.Clear();

            #endregion
        }


        #region Tool Strip Help New 0rder, Clear List and Save Order, Info/Support
        private void toolStripDropDownButton1_Click(object sender, EventArgs e)
        {

        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // The below New Order button on the Help ToolStrip creates a new order or clear job list
            jobLST.Items.Clear();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close(); // cloeses the application.
        }

        private void infoSupportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Message box will appear displaying the below
            MessageBox.Show("Babysitter Software LTD, To report a fault or request assistance with application please ring 0800 000 299 or email SBS@SampsonLTD.co.uk", "Sampsoni Babysitter Software Support");
        }
        #endregion


        #region Job Product Button Coding Morning Afternoon Evening Full Job

        //The below coding is for the Morning, Afternoon, Evening & Full Day babysitting jobs
        private void morningBTN_Click(object sender, EventArgs e)
        {
            jobLST.Items.Add("Morning Babysitter"); //add item to job list
            jobLST.Items.Add(String.Format("{0:0.00}", morning)); //add item to job list(held in a variable)
            jobpaymenttotal = jobpaymenttotal + morning;
            totalTXTBX.Text = string.Format("{0:0.00}", jobpaymenttotal).ToString(); //update Job order total text box to include new total after updating and converting to string
        }

        private void afternoonBTN_Click(object sender, EventArgs e)
        {
            jobLST.Items.Add("Afternoon Babysitter"); //add item to job list
            jobLST.Items.Add(String.Format("{0:0.00}", afternoon)); //add item to job list(held in a variable)
            jobpaymenttotal = jobpaymenttotal + afternoon;
            totalTXTBX.Text = string.Format("{0:0.00}", jobpaymenttotal).ToString(); //update Job order total text box to include new total after updating and converting to string
        }

        private void eveningBTN_Click(object sender, EventArgs e)
        {
            jobLST.Items.Add("Evening Babysitter"); //add item to job list
            jobLST.Items.Add(String.Format("{0:0.00}", evening)); //add item to job list(held in a variable)
            jobpaymenttotal = jobpaymenttotal + evening;
            totalTXTBX.Text = string.Format("{0:0.00}", jobpaymenttotal).ToString(); //update Job order total text box to include new total after updating and converting to string
        }

        private void fulldayBTN_Click(object sender, EventArgs e)
        {
            Clearlist();
            jobLST.Items.Add("Full Day Babysitter"); //add item to job list
            jobLST.Items.Add(String.Format("{0:0.00}", fullday)); //add item to job list(held in a variable)
            jobpaymenttotal = jobpaymenttotal + fullday;
            totalTXTBX.Text = string.Format("{0:0.00}", jobpaymenttotal).ToString(); //update Job order total text box to include new total after updating and converting to string



        }
        #endregion

        #region  Clear whole list of jobs on job list 
        private void clearjobBTN_Click(object sender, EventArgs e)
        {
            Clearlist();
        }

        #endregion


        #region Add Customer Address to Job list box / coding
        private void addressLST_SelectedIndexChanged(object sender, EventArgs e)
        {
            //The below code adds the customer address to the job list box


            foreach (var item in addressLST.SelectedItems)
            {

                jobLST.Items.Add("CUSTOMER ADDRESS:   " + addressLST.Text);
            }
            #endregion

        }

        #region Add Staff Name to Job List Box / coding
        private void staffLST_SelectedIndexChanged(object sender, EventArgs e)
        {

            //The below code adds the  name to the job list box


            foreach (var item in staffLST.SelectedItems)
            {

                jobLST.Items.Add("STAFF:  " + staffLST.Text);
            }
            #endregion

        }

        #region Add Date and Time to job List Box
        private void datetimeBTN_Click(object sender, EventArgs e)
        {
            jobLST.Items.Add(timeTXT.Text);
            jobLST.Items.Add(dataTXT.Text);
        }

        #endregion

        private void jobLST_SelectedIndexChanged(object sender, EventArgs e)
        {


        }

        #region Confirmation button to the customer 
        public void confirmBTN_Click(object sender, EventArgs e)
        {
            Customers F = new Customers(jobLST.Items);
            F.Show();

        }

        #endregion

        #region Allocate button to send jobs to tbe staff to confirm allocation
        public void allocateBTN_Click(object sender, EventArgs e)
        {
            Staff S = new Staff(jobLST.Items);
            S.Show();
        }

        #endregion

        #region This code WORKS simutationally with the staff interface when clicked it activates
        //staff interface when staf click accept the manager interace label displays the text inputted on staff interface
        
        public void staffacceptBTN_Click(object sender, EventArgs e)
        {
            Staff G = new Staff(this);
            G.Show();
        }

        public string labelText
        {
            get { return acceptLBL.Text; }
            set { acceptLBL.Text = value; }

        }
        #endregion
    }
}
    