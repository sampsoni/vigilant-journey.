﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BabySitterApp
{
    public partial class Staff : Form
    {

        public Staff()
        {
            InitializeComponent();
        }
        #region The below code allows interaction between two forms 

        private form1 mainForm = null;
        public Staff(Form callingForm)
        {
            mainForm = callingForm as form1;
            InitializeComponent();
        }

        public Staff(ListBox.ObjectCollection objectCollection)
        {
            InitializeComponent();

            this.staffLST.DataSource = objectCollection;
        }

        #endregion

        #region Log Out Button
        private void stlogoutBTN_Click(object sender, EventArgs e)
        {
                         

            //This code allows Staff to log out of application
            this.Close();
        }
        #endregion


        #region  This code send a text message from staff interface to manager interface
        private void acceptBTN_Click(object sender, EventArgs e)
        {
            this.mainForm.labelText = txtMessage.Text;
        }
        #endregion
    }
}

