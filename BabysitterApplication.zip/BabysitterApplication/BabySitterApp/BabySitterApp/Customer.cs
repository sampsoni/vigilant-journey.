﻿namespace BabySitterApp
{
    public class Customer : ContentPage
    {
        public Customer()
        {

        }
    }

    public class ContentPage
    {
    }
}
