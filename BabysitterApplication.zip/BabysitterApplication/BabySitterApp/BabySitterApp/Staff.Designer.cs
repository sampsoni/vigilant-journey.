﻿namespace BabySitterApp
{
    partial class Staff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Staff));
            this.stlogoutBTN = new System.Windows.Forms.Button();
            this.staffLST = new System.Windows.Forms.ListBox();
            this.acceptBTN = new System.Windows.Forms.Button();
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // stlogoutBTN
            // 
            this.stlogoutBTN.Location = new System.Drawing.Point(128, 12);
            this.stlogoutBTN.Name = "stlogoutBTN";
            this.stlogoutBTN.Size = new System.Drawing.Size(137, 53);
            this.stlogoutBTN.TabIndex = 1;
            this.stlogoutBTN.Text = "Log Out";
            this.stlogoutBTN.UseVisualStyleBackColor = true;
            this.stlogoutBTN.Click += new System.EventHandler(this.stlogoutBTN_Click);
            // 
            // staffLST
            // 
            this.staffLST.FormattingEnabled = true;
            this.staffLST.ItemHeight = 18;
            this.staffLST.Location = new System.Drawing.Point(29, 156);
            this.staffLST.Name = "staffLST";
            this.staffLST.Size = new System.Drawing.Size(339, 274);
            this.staffLST.TabIndex = 2;
            // 
            // acceptBTN
            // 
            this.acceptBTN.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.acceptBTN.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acceptBTN.Location = new System.Drawing.Point(29, 111);
            this.acceptBTN.Name = "acceptBTN";
            this.acceptBTN.Size = new System.Drawing.Size(351, 28);
            this.acceptBTN.TabIndex = 3;
            this.acceptBTN.Text = "Accepted or Decline Job";
            this.acceptBTN.UseVisualStyleBackColor = true;
            this.acceptBTN.Click += new System.EventHandler(this.acceptBTN_Click);
            // 
            // txtMessage
            // 
            this.txtMessage.Location = new System.Drawing.Point(227, 76);
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.Size = new System.Drawing.Size(141, 26);
            this.txtMessage.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 79);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 18);
            this.label1.TabIndex = 5;
            this.label1.Text = "Please type answer:";
            // 
            // Staff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(407, 442);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtMessage);
            this.Controls.Add(this.acceptBTN);
            this.Controls.Add(this.staffLST);
            this.Controls.Add(this.stlogoutBTN);
            this.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "Staff";
            this.Text = "Staff Babysitter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button stlogoutBTN;
        public System.Windows.Forms.ListBox staffLST;
        private System.Windows.Forms.Button acceptBTN;
        private System.Windows.Forms.TextBox txtMessage;
        private System.Windows.Forms.Label label1;
    }
}