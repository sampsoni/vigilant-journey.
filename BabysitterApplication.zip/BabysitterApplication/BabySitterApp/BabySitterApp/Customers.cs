﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BabySitterApp
{
    public partial class Customers : Form
    {
        public Customers()
        {
            InitializeComponent();
        }

        #region Code that allows interaction between manager interface and customer interface
        public Customers(ListBox.ObjectCollection objectCollection)
        {
            InitializeComponent();

            this.cjobLST.DataSource = objectCollection;
        }
       
        private void Customers_Load(object sender, EventArgs e)
        {

        }
        #endregion

        #region Log Out Button
        private void clogoutBTN_Click(object sender, EventArgs e)
        {
            //This code allows customer to log out of application
            this.Close();
        }
        #endregion

        private void cjobLST_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

    }
}

