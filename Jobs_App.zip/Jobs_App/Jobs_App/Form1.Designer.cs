﻿namespace Jobs_App
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.threeBTN = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.clearBTN = new System.Windows.Forms.Button();
            this.fiveBTN = new System.Windows.Forms.Button();
            this.fourBTN = new System.Windows.Forms.Button();
            this.cTXT = new System.Windows.Forms.TextBox();
            this.twoBTN = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.oneBTN = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.aTXT = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.bTXT = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.dTXT = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.eTXT = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.fTXT = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.sixBTN = new System.Windows.Forms.Button();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // threeBTN
            // 
            this.threeBTN.Location = new System.Drawing.Point(53, 317);
            this.threeBTN.Name = "threeBTN";
            this.threeBTN.Size = new System.Drawing.Size(116, 28);
            this.threeBTN.TabIndex = 0;
            this.threeBTN.Text = "Job 3";
            this.threeBTN.UseVisualStyleBackColor = true;
            this.threeBTN.Click += new System.EventHandler(this.threeBTN_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.sixBTN);
            this.panel5.Controls.Add(this.clearBTN);
            this.panel5.Controls.Add(this.fiveBTN);
            this.panel5.Controls.Add(this.fourBTN);
            this.panel5.Controls.Add(this.cTXT);
            this.panel5.Controls.Add(this.twoBTN);
            this.panel5.Controls.Add(this.threeBTN);
            this.panel5.Controls.Add(this.label16);
            this.panel5.Controls.Add(this.oneBTN);
            this.panel5.Controls.Add(this.label17);
            this.panel5.Controls.Add(this.aTXT);
            this.panel5.Controls.Add(this.label18);
            this.panel5.Controls.Add(this.bTXT);
            this.panel5.Controls.Add(this.label19);
            this.panel5.Controls.Add(this.dTXT);
            this.panel5.Controls.Add(this.label20);
            this.panel5.Controls.Add(this.eTXT);
            this.panel5.Controls.Add(this.label21);
            this.panel5.Controls.Add(this.fTXT);
            this.panel5.Controls.Add(this.label22);
            this.panel5.Location = new System.Drawing.Point(34, 12);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(216, 487);
            this.panel5.TabIndex = 17;
            // 
            // clearBTN
            // 
            this.clearBTN.Location = new System.Drawing.Point(21, 450);
            this.clearBTN.Name = "clearBTN";
            this.clearBTN.Size = new System.Drawing.Size(167, 28);
            this.clearBTN.TabIndex = 20;
            this.clearBTN.Text = "Clear Text Boxes";
            this.clearBTN.UseVisualStyleBackColor = true;
            this.clearBTN.Click += new System.EventHandler(this.clearBTN_Click);
            // 
            // fiveBTN
            // 
            this.fiveBTN.Location = new System.Drawing.Point(53, 385);
            this.fiveBTN.Name = "fiveBTN";
            this.fiveBTN.Size = new System.Drawing.Size(116, 28);
            this.fiveBTN.TabIndex = 19;
            this.fiveBTN.Text = "Job 5";
            this.fiveBTN.UseVisualStyleBackColor = true;
            this.fiveBTN.Click += new System.EventHandler(this.fiveBTN_Click);
            // 
            // fourBTN
            // 
            this.fourBTN.Location = new System.Drawing.Point(53, 351);
            this.fourBTN.Name = "fourBTN";
            this.fourBTN.Size = new System.Drawing.Size(116, 28);
            this.fourBTN.TabIndex = 18;
            this.fourBTN.Text = "Job 4";
            this.fourBTN.UseVisualStyleBackColor = true;
            this.fourBTN.Click += new System.EventHandler(this.fourBTN_Click);
            // 
            // cTXT
            // 
            this.cTXT.Location = new System.Drawing.Point(53, 121);
            this.cTXT.Name = "cTXT";
            this.cTXT.Size = new System.Drawing.Size(116, 23);
            this.cTXT.TabIndex = 3;
            // 
            // twoBTN
            // 
            this.twoBTN.Location = new System.Drawing.Point(53, 285);
            this.twoBTN.Name = "twoBTN";
            this.twoBTN.Size = new System.Drawing.Size(116, 28);
            this.twoBTN.TabIndex = 17;
            this.twoBTN.Text = "Job 2";
            this.twoBTN.UseVisualStyleBackColor = true;
            this.twoBTN.Click += new System.EventHandler(this.twoBTN_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(17, 95);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(16, 15);
            this.label16.TabIndex = 15;
            this.label16.Text = "B";
            // 
            // oneBTN
            // 
            this.oneBTN.Location = new System.Drawing.Point(53, 251);
            this.oneBTN.Name = "oneBTN";
            this.oneBTN.Size = new System.Drawing.Size(116, 28);
            this.oneBTN.TabIndex = 0;
            this.oneBTN.Text = "Job 1";
            this.oneBTN.UseVisualStyleBackColor = true;
            this.oneBTN.Click += new System.EventHandler(this.oneBTN_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(17, 124);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(17, 15);
            this.label17.TabIndex = 14;
            this.label17.Text = "C";
            // 
            // aTXT
            // 
            this.aTXT.Location = new System.Drawing.Point(53, 63);
            this.aTXT.Name = "aTXT";
            this.aTXT.Size = new System.Drawing.Size(116, 23);
            this.aTXT.TabIndex = 1;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(18, 153);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(17, 15);
            this.label18.TabIndex = 13;
            this.label18.Text = "D";
            // 
            // bTXT
            // 
            this.bTXT.Location = new System.Drawing.Point(53, 92);
            this.bTXT.Name = "bTXT";
            this.bTXT.Size = new System.Drawing.Size(116, 23);
            this.bTXT.TabIndex = 2;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(17, 179);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(16, 15);
            this.label19.TabIndex = 12;
            this.label19.Text = "E";
            // 
            // dTXT
            // 
            this.dTXT.Location = new System.Drawing.Point(53, 150);
            this.dTXT.Name = "dTXT";
            this.dTXT.Size = new System.Drawing.Size(116, 23);
            this.dTXT.TabIndex = 4;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(17, 208);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(15, 15);
            this.label20.TabIndex = 11;
            this.label20.Text = "F";
            // 
            // eTXT
            // 
            this.eTXT.Location = new System.Drawing.Point(53, 179);
            this.eTXT.Name = "eTXT";
            this.eTXT.Size = new System.Drawing.Size(116, 23);
            this.eTXT.TabIndex = 5;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(17, 66);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(16, 15);
            this.label21.TabIndex = 8;
            this.label21.Text = "A";
            // 
            // fTXT
            // 
            this.fTXT.Location = new System.Drawing.Point(53, 208);
            this.fTXT.Name = "fTXT";
            this.fTXT.Size = new System.Drawing.Size(116, 23);
            this.fTXT.TabIndex = 6;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(18, 34);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(169, 15);
            this.label22.TabIndex = 7;
            this.label22.Text = "Please enter Jobs Below:";
            // 
            // sixBTN
            // 
            this.sixBTN.Location = new System.Drawing.Point(53, 419);
            this.sixBTN.Name = "sixBTN";
            this.sixBTN.Size = new System.Drawing.Size(116, 28);
            this.sixBTN.TabIndex = 21;
            this.sixBTN.Text = "Job 6";
            this.sixBTN.UseVisualStyleBackColor = true;
            this.sixBTN.Click += new System.EventHandler(this.sixBTN_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(281, 502);
            this.Controls.Add(this.panel5);
            this.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Jobs App";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button threeBTN;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox cTXT;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button oneBTN;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox aTXT;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox bTXT;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox dTXT;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox eTXT;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox fTXT;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button twoBTN;
        private System.Windows.Forms.Button fourBTN;
        private System.Windows.Forms.Button fiveBTN;
        private System.Windows.Forms.Button clearBTN;
        private System.Windows.Forms.Button sixBTN;
    }
}

