﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jobs_App
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {


        }
        #region Custom Methods = Textboxes with no data inputted

        //the below method code informs the user that text boxes are have no data added, empty sequence
        private void Emptytextboxes()

        {
            if (aTXT.Text == String.Empty || bTXT.Text == String.Empty || cTXT.Text == String.Empty || dTXT.Text == String.Empty || eTXT.Text == String.Empty || fTXT.Text == String.Empty)

                MessageBox.Show("Error:(no jobs), empty sequence.");
        }


        #endregion
        //The below code for button one displays results when the 1st job is inputted into textbox A
        private void oneBTN_Click(object sender, EventArgs e)

        {
            Emptytextboxes();
            string joblist;
            joblist = aTXT.Text;
            MessageBox.Show("sequence consisting of a single job " + joblist);

        }

        //The below code clears all the text boxes once the 'Clear all text boxes' button is pressed
        private void clearBTN_Click(object sender, EventArgs e)
        {
            //code clears all text boxes
            aTXT.Clear();
            bTXT.Clear();
            cTXT.Clear();
            dTXT.Clear();
            eTXT.Clear();
            fTXT.Clear();
        }

        private void twoBTN_Click(object sender, EventArgs e)
        {
            //The below code for button 2 will display result a a sequence containing all three jobs abc in no significant order.
            MessageBox.Show("  B:  " + bTXT.Text + "  C:   " + cTXT.Text + "  A: " + aTXT.Text);
        }

        private void threeBTN_Click(object sender, EventArgs e)
        {

            // The below code for button 3 will display result in a sequence that positions c before b, containing all three jobs abc.

            MessageBox.Show("  A:  " + aTXT.Text + "  C:   " + cTXT.Text + "  B: " + bTXT.Text);

        }

        private void fourBTN_Click(object sender, EventArgs e)
        {
            //The below code for button 4 will dsiplay result in a sequence that positions f before c, c before b, b before e and a before d containing all six jobs abcdef.
            MessageBox.Show("  F:  " + fTXT.Text + "  C:   " + cTXT.Text + "  B: " + bTXT.Text + "  E: " + eTXT.Text + "  A:" + aTXT.Text + "  D:" + dTXT.Text);
        }

        private void fiveBTN_Click(object sender, EventArgs e)
        {
            //The below code for button 6  result displays an error stating that jobs can’t depend on themselves.
            MessageBox.Show("Error: Jobs can’t depend on themselves");
        }

        private void sixBTN_Click(object sender, EventArgs e)
        {
            //The below code for button 6  result displays an error stating that jobs can’t have circular dependencies.
            MessageBox.Show("Error: Jobs can’t have circular dependencies.");
        }
    }
}